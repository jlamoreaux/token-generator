var districts = [
  {
    "name" : "South Redford",
    "url" : "https://web.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1NDE4NzMyNzEsImVtYWlsIjoic3RvY2tlbUBzb3V0aHJlZGZvcmQub3JnIiwicHJvamVjdElkIjoxMDk0NX0.rYak1EgiW0HwVOBnqKCZ-ffJN5iV3iRW2aWf3VDUyho"
  },
  {
    "name" : "PACE Academy",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1NDAwNzU2MDcsImVtYWlsIjoiYW11bGxlbkBwYWNlay04Lm9yZyIsInByb2plY3RJZCI6ODYwOH0.e6uGz4Br9ZxENXWauZ7oJRLRavcr5RmyBKPE2zPb8rY"
  },
  {
    "name" : "Springcove",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1Mzk2NDUxMDEsImVtYWlsIjoiYmJha2VyQHNwcmluZ2NvdmVzZC5vcmciLCJwcm9qZWN0SWQiOjEwMTg0fQ.M6J6SiT92tPqTxJwYg9BF9AlhV5dzt4SvXjC2TMfmVI"
  },
  {
    "name" : "Columbia County Schools",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1Mzg3NTMzMjIsImVtYWlsIjoibmljaG9sYXMuY2Fycm9sbEBjY2JvZS5uZXQiLCJwcm9qZWN0SWQiOjEwMDI5fQ.ueKXtPOLUN3VfSspoOrh6s2dgNXsZsPVk48qJQrd8fU"
  },
  {
    "name" : "Kilmanjaro",
    "url" : ""
  },
  {
    "name" : "Ascend Leadership Academy",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1Mzg3NTMzMjIsImVtYWlsIjoianNtaXRoQGFsYXNjaG9vbHNuYy5vcmciLCJwcm9qZWN0SWQiOjExMzg0fQ.7gaQp267X1hHVkwlC3e5tdxa0CK332wO3B2HGW3_XOI"
  },
  {
    "name" : "Burke County",
    "url" : "https://web.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1Mzc5MTE1OTcsImVtYWlsIjoiYWpudW5uYWxseUBidXJrZS5rMTIuZ2EudXMiLCJwcm9qZWN0SWQiOjQ4OTJ9.STu8cOnHHnqVY0Zxl5CZuut4YGs40l8KLAdVPc6o7jU"
  },
  {
    "name" : "Eaton Rapids",
    "url" : "https://web.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1Mzc1Njc0NTcsImVtYWlsIjoicnNvdXRoQGVycHNrMTIub3JnIiwicHJvamVjdElkIjoxMTE2Mn0.v-EWkD29DFIwHfblDJlquQTq2cMuE-vq7pZPkuOTM2c"
  },
  {
    "name" : "IDEA Public Charter School",
    "url" : "https://web.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzY3MDAzOTksImVtYWlsIjoianJ5ZHN0cm9tQGlkZWFwY3Mub3JnIiwicHJvamVjdElkIjo2NzMyfQ.JTJiPO4RRt_aIHXolaKM6APKWJeQeQg0tQpipJw9lFM"
  },
  {
    "name" : "Portsmouth Christian",
    "url" : "https://web.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzY3MDAzOTksImVtYWlsIjoiamNvbGxpbnNAcG9ydHNtb3V0aGNocmlzdGlhbi5vcmciLCJwcm9qZWN0SWQiOjExMzU3fQ._5H5XNow16x_HWYYAveKcDbSuDfiAZPLwKT3h0x9y5c"
  },
  {
    "name" : "City Height Prep",
    "url" : ""
  },
  {
    "name" : "Parkway Elementary School",
    "url" : ""
  },
  {
    "name" : "Palm Lane Charter",
    "url" : "https://web.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzY3MDAzOTksImVtYWlsIjoidGZpc2hAcGFsbWxhbmVjaGFydGVyc2Nob29sLm9yZyIsInByb2plY3RJZCI6MTEzMjF9.-tk8PXR9Ga_wZS6icJRTDeoSOJLLym5J98MnBN8mDkc"
  },
  {
    "name" : "University Academy",
    "url" : ""
  },
  {
    "name" : "St. Bede School",
    "url" : ""
  },
  {
    "name" : "Cherokee County School District",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzQ2MzA5NzEsImVtYWlsIjoia2FyaW4uZHJlc2NoZXJAYnJhZGZvcmRwcmVwLm9yZyIsInByb2plY3RJZCI6ODk0M30.88hSmtH1A3CaqQJLhcMOx1anNhHIzt6U7s26Y1xK_IM"
  },
  {
    "name" : "Rowlett Academy",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzcwNDc1MTgsImVtYWlsIjoibGV2ZXllQHJvd2xldHRhY2FkZW15Lm9yZyIsInByb2plY3RJZCI6MTEwMjl9.eZbJ_ZBHL7Ko8lbFgkHCRpnpdSuqpgokc78hxcQW9mY"
  },
  {
    "name" : "St. John Paul",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzU2NTM3MzQsImVtYWlsIjoiZGF2aWQubW9yYWxlc0BqcHRoZWdyZWF0Lm9yZyIsInByb2plY3RJZCI6MTEyODJ9.H45jrfsHwDaJM3U8VtouLmSU-5uVYP0tw9zFf-gnCH4"
  },
  {
    "name" : "Our Community School",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzQ2MzA5NzEsImVtYWlsIjoidmFsZXJpZS5kQG91cmNvbW11bml0eXNjaG9vbC5vcmciLCJwcm9qZWN0SWQiOjY3Nzl9.IDiMHHWoh2geLA-Y4bSs2elFsZj6VN9V6uBXfsioAos"
  },
  {
    "name" : "Bradford Prepatory School",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzQ2MzA5NzEsImVtYWlsIjoia2FyaW4uZHJlc2NoZXJAYnJhZGZvcmRwcmVwLm9yZyIsInByb2plY3RJZCI6ODk0M30.88hSmtH1A3CaqQJLhcMOx1anNhHIzt6U7s26Y1xK_IM"
  },
  {
    "name" : "Coloma Community School District",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzQ2MzA5NzEsImVtYWlsIjoidGtpbW1lcmx5QGNjcy5jb2xvbWEub3JnIiwicHJvamVjdElkIjo2MjgxfQ.EG1HGacHBnkYIGFS5G14TV0soa7vwukTH14gwKBs0wA"
  },
  {
    "name" : "Jeanette City School District",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzQ2MzA5NzEsImVtYWlsIjoidGtpbW1lcmx5QGNjcy5jb2xvbWEub3JnIiwicHJvamVjdElkIjo2MjgxfQ.EG1HGacHBnkYIGFS5G14TV0soa7vwukTH14gwKBs0wA"
  },
  {
    "name" : "Jeanette City School District",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzQ2MzA5NzEsImVtYWlsIjoidGtpbW1lcmx5QGNjcy5jb2xvbWEub3JnIiwicHJvamVjdElkIjo2MjgxfQ.EG1HGacHBnkYIGFS5G14TV0soa7vwukTH14gwKBs0wA"
  },
  {
    "name" : "Gause ISD",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzQ2MzA5NzEsImVtYWlsIjoibHRheWxvckBnYXVzZWlzZC5uZXQiLCJwcm9qZWN0SWQiOjExMTU4fQ.CKiEmdGLwVFFSkNJcHaTCxhB7UqeKHkffMCey8-FoME"
  },
  {
    "name" : "Farmersville ISD",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzQ2MzA5NzEsImVtYWlsIjoiZm1haGFmZmV5QGZhcm1lcnN2aWxsZWlzZC5vcmciLCJwcm9qZWN0SWQiOjYyMTF9.zAulC6NZzRG5KnLohOOJZzkn4GVqKg8OMuDTxK4tVn8"
  },
  {
    "name" : "Spring Cove SD",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzQ2MzA5NzEsImVtYWlsIjoiYmJha2VyQHNwcmluZ2NvdmVzZC5vcmciLCJwcm9qZWN0SWQiOjEwMTg0fQ.8vv8vTbGRn8GclVsRNgEWkw38Pzg6TITIfnijj0VGlE"
  },
  {
    "name" : "San Gabriel Unified School District",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1Mzc5MDYzNDAsImVtYWlsIjoiZmFybnlfakBzZ3VzZC5rMTIuY2EudXMiLCJwcm9qZWN0SWQiOjU3NjV9.1_Nguw0He9b5Wnboq6X6447Jq1eqEvXWagxM6-EFvkQ"
  },
  {
    "name" : "Rockwern Academy",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzM5MjQ1NzgsImVtYWlsIjoiamV3ZXRoaW5ndG9uQHJvY2t3ZXJuYWNhZGVteS5vcmciLCJwcm9qZWN0SWQiOjEwNTM4fQ.ERnIsPX1nG_EAEe0iEp5FKClWyNdBPxu8VWP6lYKxMk"
  },
  {
    "name" : "St. Louise",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzUyMjMzODQsImVtYWlsIjoiZGFua0BzdGxvdWlzZXNjaG9vbC5vcmciLCJwcm9qZWN0SWQiOjMyOTd9.WlgNdUTXD9i65mUlTqGoIa3_vKHCiLX7Bz__QCkPjEk"
  },
  {
    "name" : "Greeneville CS",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzM5MjQ1NzgsImVtYWlsIjoiam9uZXNsQGdjc2Nob29scy5uZXQiLCJwcm9qZWN0SWQiOjk5MTl9.ENQNML-oRuUROrwMJeNLXeamn9Iuebdc7Pq1JrhqeG0"
  },
  {
    "name" : "Desert Star Community School",
    "url" : ""
  },
  {
    "name" : "International School of Panama",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzM5MjQ1NzgsImVtYWlsIjoiamd1ZXZhcmFAaXNwLmVkdS5wYSIsInByb2plY3RJZCI6OTgxMn0.HtnaY0CTGHGax05pCYhu2HBepCfyP2qV5Fne2vq_Htw"
  },
  {
    "name" : "Ferris ISD",
    "url" : ""
  },
  {
    "name" : "Columbia County Schools",
    "url" : "https://www.sanghapp.com/cmslogin?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI5Nzc1NzMsImVtYWlsIjoibmljaG9sYXMuY2Fycm9sbEBjY2JvZS5uZXQiLCJwcm9qZWN0SWQiOjEwMDI5fQ.Ebhg99E35oNJ9n3c_czU8rZNF6X7Bj6DmpzRul8CpB4"
  },
  {
    "name" : "Hempfield Area School District",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI4MTcwOTksImVtYWlsIjoid2FnbmVyYm1AaGFzZHBhLm5ldCIsInByb2plY3RJZCI6MTA0Mjl9.WRNL6wIHSQtN0LOGXjxwpLTsW2K4n5OkI9IVoKlasSw"
  },
  {
    "name" : "Vinton County Local School District",
    "url" : ""
  },
  {
    "name" : "Carteret Public Schools",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI2OTcyMDEsImVtYWlsIjoid2ViQGNhcnRlcmV0c2Nob29scy5vcmciLCJwcm9qZWN0SWQiOjExMDY3fQ._WXpH-kuitRxoE3eBd7_C4RSqyKnPzhp46Hwdyb3wxo"
  },
  {
    "name" : "Addison SD 4",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI2NDkwMTcsImVtYWlsIjoia2xvaHNlQGFzZDQub3JnIiwicHJvamVjdElkIjoxMDcyMH0.4y99zr3wxB41sWiUOMtkHwn7V_WoHbRHxJGdPql4XFw"
  },
  {
    "name" : "Robert Russa Moton Charter School",
    "url" : ""
  },
  {
    "name" : "Eastern Lancaster",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzIwNDI4ODYsImVtYWlsIjoidGFxdWlub0Bob3dlbGwuazEyLm5qLnVzIiwicHJvamVjdElkIjoxMDAwMn0.sk-hc5KtloKn80SVeZ_kv7EwOTTJxEcwcE_QlwBd5y0"
  },
  {
    "name" : "Howell Township Public Schools",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzQwOTg2MTMwMDAsImVtYWlsIjoidGFxdWlub0Bob3dlbGwuazEyLm5qLnVzIiwicHJvamVjdElkIjoxMDAwMn0.k0tSjGZoyRwlGhgRiy1XNo48iRs_3WZQXKC7w8VeITE"
  },
  {
    "name" : "Pamona Unified School District",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzE3Njk4MTgsImVtYWlsIjoiZ2luby5wZXRyaXZlbGxpQHB1c2Qub3JnIiwicHJvamVjdElkIjoxMDU5NX0.D9o3-uHrxjw6BZvN8MjmEgA3qdRteGhcYkbmT1DeJyc"
  },
  {
    "name" : "La Vega City School District",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzUzMjA2NDIsImVtYWlsIjoiY2hyaXMuYm9ybGFuZEBsYXZlZ2Fpc2Qub3JnIiwicHJvamVjdElkIjoxODg1fQ.yg2kkM9LOEkYLjkbZsaNj850CzwylxrAbmETJdhPUT8"
  },
  {
    "name" : "La Vega City School District",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzUzMjA2NDIsImVtYWlsIjoiY2hyaXMuYm9ybGFuZEBsYXZlZ2Fpc2Qub3JnIiwicHJvamVjdElkIjoxODg1fQ.yg2kkM9LOEkYLjkbZsaNj850CzwylxrAbmETJdhPUT8"
  },
  {
    "name" : "Beavercreek City School District",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzI5NTYzMjAsImVtYWlsIjoic2h1bWFubUBiZWF2ZXJjcmVlay5rMTIub2gudXMiLCJwcm9qZWN0SWQiOjEwMjQ3fQ.U3yxLeijVxpx3NQ7AEGiBIoQVY88EwneoSdynxT0_HU"
  },
  {
    "name" : "San Lorenzo Unified School District",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzAzOTgzNjUsImVtYWlsIjoiZm5nQHNsenVzZC5vcmciLCJwcm9qZWN0SWQiOjEwMDc3fQ.Hw8zaWs97jymuAyHow3tSePnVZcM-kkgbD-NZeCDWDA"
  },
  {
    "name" : "Penns Valley",
    "url" : "https://www.sanghapp.com/cmsauth?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1MzY1MjI4MTcsImVtYWlsIjoiY3dpYW5AcGVubnN2YWxsZXkub3JnIiwicHJvamVjdElkIjoxMDE0N30.2eeNmRV097LgFxdeiRNB8GujPlL1FNWaW49CgBF3CX0"
  },
  {
    "name" : "Coal City Community School District 1",
    "url" : ""
  },
]
